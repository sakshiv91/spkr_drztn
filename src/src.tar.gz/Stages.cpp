#include "Includes.h" 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	Global declarations
	string 	path ;
	int 	featDim ;
	vvc 	speechData ;
	int 	initCluster ;
	int 	initMixture ;
	string 	fileName ;
	int 	numFeats ;
	vvvc 	segmentData ;
	vvvc 	clusterData ;
	vi 		clusterMixtures ;
	int 	segmentationItr ; 
	int 	chunkSize = 250;
	vi 		gmmIds ;
	string 	sdatapath;
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// read whole speech data in vector of vector of double speechData

void readData(vvc &data, string fileName){
	ifstream infile((fileName).c_str());
	string s;
	stringstream ss;
	int c ;
	vc feature;
	int me = 0;
	while(getline(infile, s)){
		ss << s;
		double num;
		c = 0;
		fr(i, 0, featDim){
			ss >> num;
			feature.push_back(num);
		}
		data.push_back(feature);
		feature.clear();
		cs(ss);
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Divide equally initial data amongst all the clusters
// After dividing there is no concept of boundaries betweenn the segments
void initClusters(int &k, vvvc &data){
	numFeats = speechData.size();
	int clusterFeatures = numFeats/k ;
	int count = 0;
	vvc temp ;
	fr(i, 0, k){
		do{
			temp.push_back(speechData[count++]);
		}while(count%clusterFeatures != 0);
		data.push_back(temp);
		temp.clear();
	}
	int rem = numFeats - count;
	if(rem > 0.9*clusterFeatures){
		while(count < numFeats){
			temp.push_back(speechData[count++]);
			k++;
		}
		data.push_back(temp);
	}
	else{
		while(count < numFeats){
			data[k-1].push_back(speechData[count++]);
		}
	}
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Initializing K clusters randomly by dividing the data in random fashion
void randomInit(int k, vvc &data, vvvc &randomData){
	vi lines(data.size(), 0);
	fr(i, 0, lines.size()){
		lines[i] = i;
	}
	int chunkSize = data.size()/k;
	srand(time(0));
	random_shuffle(lines.begin(), lines.end());
	int count = 0;
	vc feat;
	vvc chunk;
	fr(i, 0, k){
		do{
			chunk.push_back(data[lines[count++]]); 
		}while(count%chunkSize!=0);
		randomData.push_back(chunk);
		chunk.clear();
	}
	int rem = data.size() - count;
	if(rem > 0){
		while(count < data.size()){
			randomData[k-1].push_back(data[lines[count++]]);
		}
	}
}
//Initializing mixture clusters
void initClusterMixtures(int k){
	fr(i, 0, k)
		clusterMixtures.push_back(initMixture);
}
//Initializing gmmIds
void initGMMId(map<int, Ptr<EM>> &gmms){
	int id = -1;
	fr(i, 0, segmentData.size()){
		gmmIds.push_back(id);
	}
}

//Make a matrix for gmm data seeing gmmIds. with gmm id 10 mat will have all the segments' data that belongs to id 10
Mat makeData(int clusterId, vvvc &clusterData, vi &gmmIds){
        vvc iData;		
        fr(i, 0, gmmIds.size()){
                if(gmmIds[i] == clusterId){
                        fr(j, 0, clusterData[i].size()){
                                iData.push_back(clusterData[i][j]);
                        }
                }
        }
        return d2vecToMat(iData);
}

//Compute llh for testing purpose
double computeLLH(Ptr<EM> gmm, Mat data){
        double llh = 0;
        fr(i, 0, data.size().height){
                llh += gmm->predict2(data.row(i), noArray())[0];
        }
        return llh /= data.size().height;//Not normalized for BIC
}
//Compute llh for BIC
double computeLLHforBIC(Ptr<EM> gmm, Mat data){
        double llh = 0;
        fr(i, 0, data.size().height){
                llh += gmm->predict2(data.row(i), noArray())[0];
        }
        return llh;//Not normalized for BIC
}

//train a GMM
Ptr<EM> oneGMM(Mat &data, double &llh, int nc){
	Mat labels, logLikelihoods;
	double l1;
	Ptr<EM> gmmmodel = cv::ml::EM::create();
	gmmmodel->setClustersNumber(nc);
    gmmmodel->setCovarianceMatrixType(EM::COV_MAT_DIAGONAL);
	gmmmodel->setTermCriteria(TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 5, 0.1));
	gmmmodel->trainEM( data, logLikelihoods, labels, noArray());
	fr(i, 0, data.size().height){
		llh = llh + logLikelihoods.at<double>(i);
	}
	llh = llh / data.size().height;
	return gmmmodel;
}

//Train gmms initially
void gmmTrain(map<int, Ptr<EM> > &gmms, vvvc &data){
	int size = data.size() ;
	double llh;
	int gmmNo = 0;
	fr(i, 0, size){
		Mat oneClusterData = d2vecToMat(data[i]);
		Ptr<EM> gmm = oneGMM(oneClusterData, llh, clusterMixtures[i]);
		cout << "Cluster " << i << ": " << llh << endl;
		gmms.insert(make_pair(gmmNo, gmm));
		gmmNo++ ;
	}
}

//Polling and resegmentation
void segmentationAndPolling(map<int, Ptr<EM> > &gmms){
	vc testFea ;
	double ll, max_ll;
	int gmmId ;
	Mat prob ;
	int bestGmm = -1;
	cout << segmentData.size() << endl;
	fr(i, 0, segmentData.size()){
		vi pollResults(initCluster, 0);
		fr(j, 0, segmentData[i].size()){
			testFea = segmentData[i][j];
			max_ll = INT_MAX ;
			bestGmm = -1;
			tr(gmms, it){
				ll = it->second -> predict2(testFea, prob)[0] ;
				if(ll < max_ll){
					max_ll = ll ;
					bestGmm = it -> first;
				}
			}
			pollResults[bestGmm]++;
		}
		gmmIds[i] = max_element(pollResults.begin(), pollResults.end()) - pollResults.begin();
	}
	updateMap(gmms, gmmIds);
}

//get unique gmm ids that are present at current iteration
vi getUniqueIds(map<int, Ptr<EM>> &gmms){
	vi uniqueSet;
	tr(gmms, it){
		if(find(uniqueSet.begin(), uniqueSet.end(), it->first) == uniqueSet.end()){
			uniqueSet.push_back(it->first);
		}
	}
	return uniqueSet;
}

//update gmms by training after resegmenting as data changes for each gmm
void makeGMMs(map<int, Ptr<EM>> &gmms, vvvc segmentData, vi &clusterMixs){
	vi uniqueSet = getUniqueIds(gmms);
	double llh;
	tr(uniqueSet, it){
		Mat data = makeData(*it, segmentData, gmmIds);
		Ptr<EM> gmm = oneGMM(data, llh, clusterMixs[*it]);
		gmms[*it] = gmm;
	}
}


//update data structures after merging two clusters
void updateDts(int s1, int s2, map<int, Ptr<EM>> &gmms, vi &gmmIds, vi &clusterMixs){
	fr(i, 0, gmmIds.size()){
		if(gmmIds[i] == s2){
			gmmIds[i] = s1;
		}
	}
	clusterMixs[s1] += clusterMixs[s2];
	updateMap(gmms, gmmIds);
}

//Agglomerative clustering
void aggloClust(vvvc &clusterData, map<int, Ptr<EM>> &gmms, vi &gmmIds, vi &clusterMixs){
	double llh1, llh2, llh3;
	vi ids = getUniqueIds(gmms);
	printv(ids, int);
	map<double, pair<int, int>> likelihoods;
	fr(ii, 0, ids.size()){
		fr(jj, ii+1, ids.size()){
		int i = ids[ii], j = ids[jj];
		cout << i << " " << j << ": ";
			Mat probs;
			Mat data1 = makeData(i, clusterData, gmmIds);
			Mat data2 = makeData(j, clusterData, gmmIds);
			llh1 = computeLLHforBIC(gmms[i], data1);
			llh2 = computeLLHforBIC(gmms[j], data2);
			Mat data;
			vconcat(data1, data2, data);
			Ptr<EM> gmm = oneGMM(data, llh3, clusterMixtures[i]);//+clusterMixtures[j]);
			llh3 = computeLLHforBIC(gmm, data);
			cout << llh1 << " " << llh2 << " " << llh3 << " " << llh3-llh2-llh1 << endl;
			likelihoods.insert(pair<double, pair<int, int>>(llh3-llh2-llh1, pair<int, int>(i, j)));
		}
	}
	int s1 = likelihoods.begin()->second.first;
	int s2 = likelihoods.begin()->second.second;
	cout << s1 << " " << s2 << endl;
	updateDts(s1, s2, gmms, gmmIds, clusterMixs);
	printv(gmmIds, int);
	printv(clusterMixs, int);
	tr(gmms, it){
		cout << it->first << endl;
	}

}


map<int, Ptr<EM>> doSpeakerThing(string sdatapath, vvc &speechData){
	ifstream sfile(sdatapath);
	string s;
	stringstream ss;
	int sid, sf, ef;
	map<int, vvc> sdata;
	while(getline(sfile, s)){
		cs(ss);
		ss.str(s);
		ss >> sid >> sf >> ef;
		fr(i, sf, ef){
			sdata[sid].push_back(speechData[i]);
		}
	}
	printv(sdata[0][0], double);
	map<int, Ptr<EM>> sgmms;
	double llh;
	tr(sdata, it){
		cout << it->first << " " << sdata[it->first].size() << endl;
		Mat data = d2vecToMat(sdata[it->first]);
		Ptr<EM> gmm = oneGMM(data, llh, 5);
		sgmms.insert(pair<int, Ptr<EM>>(it->first, gmm));
	}
	return sgmms;
}
int main(int argc, char* argv[]){

//	We are assuming we have speech features.
//	Command line arguments
	path 			= argv[1];
	featDim 		= ston(argv[2]);
	initCluster 	= ston(argv[3]);
	fileName 		= argv[4];
	initMixture 	= ston(argv[5]);
	segmentationItr = ston(argv[6]);
	sdatapath	= argv[7];

// flat Start
	readData(speechData, fileName);
	initClusters(initCluster, clusterData);
	map<int, Ptr<EM> > gmms;
	vc likelihoods ;
	vvvc randomData;
	initClusterMixtures(initCluster);
	randomInit(initCluster, speechData, randomData);
	cout << sdatapath << endl;
	gmmTrain(gmms, randomData);
	clusterData.shrink_to_fit();

// Preparing initial Segments
	int sizeForSeg = speechData.size()/chunkSize;
	initClusters(sizeForSeg, segmentData);
// Initializing gmmId for each segment
	initGMMId(gmms);
	
	
//Segmentation
	map<int, Ptr<EM>> sgmms = doSpeakerThing(sdatapath, speechData);
	cout << sgmms.size() << endl;
	fr(i, 0, segmentationItr){
		segmentationAndPolling(sgmms);
		printv(gmmIds, int);
		cout << endl;
		tr(gmms, it)
		cout << it->first << " ";
		//makeGMMs(gmms, segmentData, clusterMixtures);
		break;
	}
	cout << endl;
	initCluster = 20;
	printv(gmmIds, int);
	//aggloClust(segmentData, gmms, gmmIds, clusterMixtures);
	return 0;
}
